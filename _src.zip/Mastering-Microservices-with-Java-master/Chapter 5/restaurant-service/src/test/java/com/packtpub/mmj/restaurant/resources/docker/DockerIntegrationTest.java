package com.packtpub.mmj.restaurant.resources.docker;

/**
 *
 * @author Sourabh Sharma
 */
public interface DockerIntegrationTest {
    // Marker for Docker integratino Tests
}
